#include <stdio.h>
int main()
{
	long a, b;
	long c;
	printf("Nhap so dien thang truoc:");
	scanf_s("%d", &a);
	printf("Nhap so dien thang nay:");
	scanf_s("%d", &b);
		c = a - b;
	printf("So Kwh dien hien tai:%d ", c);
}

