#include <stdio.h>
#include <math.h>
int main()
{
	float Pi = 3.14, e = 2.71;
	double x, y1, y2;
	printf("Nhap x:");
	scanf_s("%lf", &x);
	y1 = 4 * (x * x + (10 * x * sqrt(x)) + (3 * x) + 1);
	y2 = ((sin(Pi * (x * x)) + sqrt((x * x) + 1))) / ((pow(e, (2 * x)) + cos((Pi / 4) * x)));
	printf("Ket qua cua y1 la:%lf\n", y1);
	printf("Ket qua cua y2 la:%lf", y2);


}