#include <stdio.h>
int main()
{
	unsigned int a, b;
	printf("Nhap a la:");
	scanf_s("%d", &a);
	printf("Nhap b la:");
	scanf_s("%d", &b);
	int doiso = a;
	a = b;
	b = doiso;
	printf("\na=%d\tb=%d", a, b);




}